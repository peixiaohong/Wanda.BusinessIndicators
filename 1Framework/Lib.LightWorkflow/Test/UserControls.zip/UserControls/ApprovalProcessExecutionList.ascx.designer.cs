﻿//------------------------------------------------------------------------------
// <自动生成>
//     此代码由工具生成。
//
//     对此文件的更改可能会导致不正确的行为，并且如果
//     重新生成代码，这些更改将会丢失。 
// </自动生成>
//------------------------------------------------------------------------------

namespace Wanda.Financing.Web.UserControls {
    
    
    public partial class ApprovalProcessExecutionList {
        
        /// <summary>
        /// CtlApprovalExCurrent 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalExCurrent;
        
        /// <summary>
        /// CtlApprovalEx1 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx1;
        
        /// <summary>
        /// CtlApprovalEx2 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx2;
        
        /// <summary>
        /// CtlApprovalEx3 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx3;
        
        /// <summary>
        /// CtlApprovalEx4 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx4;
        
        /// <summary>
        /// CtlApprovalEx5 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx5;
        
        /// <summary>
        /// CtlApprovalEx6 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx6;
        
        /// <summary>
        /// CtlApprovalEx7 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx7;
        
        /// <summary>
        /// CtlApprovalEx8 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Wanda.Financing.Web.UserControls.ApprovalProcessExecution CtlApprovalEx8;
    }
}
